global.prefa = ['','!','.',',','🐤','🗿']

global.owner = ['6282274542640']
global.botname = 'CyberdarkBOT'
global.baileys1 = require('@whiskeysockets/baileys') 
global.sticker1 = "Ellen Official"
global.sticker2 = "🌜"